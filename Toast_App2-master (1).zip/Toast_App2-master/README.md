# KnowEco 
<img src="ic_final_logo.png" alt="KnowEco logo" style="height: 100px; width:100px;"/>
<h2> Demo https://youtu.be/uzwLQayn_A4 </h3>

<h2>
  <p> - Mobile app made for *Hack This Fall'*  season 2
<p> - *Realtime* Blog creation and access using *FireBase Firestore Database*.
<p> - Fetched Data related to nature from *News Api* using OkHttpClient
<p> - Implemented *payment* Using *Razorpay Android SDK*.
<p> - Donation *receipt* after successful payment verification .</h2>

<h1> Video Link : https://youtu.be/u86Rmgy48VE
  </h1>
Download the apk from here : https://github.com/RahulSoni0/KnowEco/blob/master/app/release/app-release.apk
